document.addEventListener('DOMContentLoaded', function() {
  var wholePageLink = document.getElementById('wholePageLink');
  wholePageLink.style.display = 'block'; 
  wholePageLink.style.width = '100%'; 
  wholePageLink.style.height = '100%'; 
  wholePageLink.style.position = 'absolute'; 
  wholePageLink.style.top = '0'; 
  wholePageLink.style.left = '0'; 

});
